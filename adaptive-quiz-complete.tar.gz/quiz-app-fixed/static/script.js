// Global state management
class QuizState {
    constructor() {
        this.currentQuestion = null;
        this.score = 100;
        this.questionNumber = 1;
        this.difficulty = 'medium';
        this.topic = '';
        this.contentSource = '';
        this.selectedAnswer = null;
        this.correctStreak = 0;
        this.wrongStreak = 0;
        this.compensationNeeded = 0; // For 3:1 ratio
        this.totalQuestions = 0;
        this.correctAnswers = 0;
        this.masteryProgress = 0;
    }

    updateScore(isCorrect) {
        if (isCorrect) {
            this.score += 10;
            this.correctAnswers++;
            this.correctStreak++;
            this.wrongStreak = 0;
            if (this.compensationNeeded > 0) {
                this.compensationNeeded--;
            }
        } else {
            this.score -= 5;
            this.correctStreak = 0;
            this.wrongStreak++;
            this.compensationNeeded += 3; // 3:1 compensation ratio
        }
        this.totalQuestions++;
        this.updateMasteryProgress();
    }

    updateMasteryProgress() {
        if (this.totalQuestions === 0) {
            this.masteryProgress = 0;
        } else {
            // Base mastery on accuracy and compensation status
            const accuracy = this.correctAnswers / this.totalQuestions;
            const compensationPenalty = Math.min(this.compensationNeeded * 0.1, 0.5);
            this.masteryProgress = Math.max(0, (accuracy - compensationPenalty) * 100);
        }
    }

    adjustDifficulty() {
        const difficulties = ['easy', 'medium', 'hard'];
        const currentIndex = difficulties.indexOf(this.difficulty);
        
        // If compensation is needed, stay at easier levels
        if (this.compensationNeeded > 0) {
            if (currentIndex > 0) {
                this.difficulty = difficulties[currentIndex - 1];
            }
            return;
        }

        // Increase difficulty after consistent correct answers
        if (this.correctStreak >= 3 && currentIndex < difficulties.length - 1) {
            this.difficulty = difficulties[currentIndex + 1];
            this.correctStreak = 0; // Reset streak after difficulty increase
        }
        // Decrease difficulty after wrong answers
        else if (this.wrongStreak >= 1 && currentIndex > 0) {
            this.difficulty = difficulties[currentIndex - 1];
        }
    }
}

// Initialize global state
const quizState = new QuizState();

// API configuration
const API_BASE_URL = window.location.origin + '/api';

// Utility functions
function showScreen(screenId) {
    document.querySelectorAll('.screen').forEach(screen => {
        screen.classList.remove('active');
    });
    document.getElementById(screenId).classList.add('active');
}

function showError(message) {
    document.getElementById('error-message').textContent = message;
    showScreen('error-screen');
}

function updateProgressDisplay() {
    document.getElementById('question-number').textContent = quizState.questionNumber;
    document.getElementById('current-score').textContent = quizState.score;
    document.getElementById('current-difficulty').textContent = 
        quizState.difficulty.charAt(0).toUpperCase() + quizState.difficulty.slice(1);
    
    // Update mastery progress bar
    const masteryFill = document.getElementById('mastery-fill');
    masteryFill.style.width = `${quizState.masteryProgress}%`;
}

// File upload handling
function initializeFileUpload() {
    const fileInput = document.getElementById('file-input');
    const fileUploadArea = document.getElementById('file-upload-area');
    const uploadBtn = document.getElementById('upload-btn');

    // Click to upload
    fileUploadArea.addEventListener('click', () => {
        fileInput.click();
    });

    // File selection
    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            updateFileUploadUI(file);
            uploadBtn.disabled = false;
        }
    });

    // Drag and drop
    fileUploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        fileUploadArea.classList.add('dragover');
    });

    fileUploadArea.addEventListener('dragleave', () => {
        fileUploadArea.classList.remove('dragover');
    });

    fileUploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        fileUploadArea.classList.remove('dragover');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            const file = files[0];
            if (file.type === 'application/pdf' || file.type === 'text/plain') {
                fileInput.files = files;
                updateFileUploadUI(file);
                uploadBtn.disabled = false;
            } else {
                alert('Please upload only PDF or TXT files.');
            }
        }
    });

    // Upload button
    uploadBtn.addEventListener('click', () => {
        const file = fileInput.files[0];
        if (file) {
            uploadFile(file);
        }
    });
}

function updateFileUploadUI(file) {
    const uploadContent = document.querySelector('.upload-content');
    uploadContent.innerHTML = `
        <i class="fas fa-file-check"></i>
        <p><strong>${file.name}</strong></p>
        <span>File selected (${(file.size / 1024 / 1024).toFixed(2)} MB)</span>
    `;
}

// Topic input handling
function initializeTopicInput() {
    const topicInput = document.getElementById('topic-input');
    const topicBtn = document.getElementById('topic-btn');
    const charCount = document.getElementById('char-count');

    topicInput.addEventListener('input', (e) => {
        const value = e.target.value;
        charCount.textContent = value.length;
        topicBtn.disabled = value.trim().length === 0;
    });

    topicInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !topicBtn.disabled) {
            startTopicQuiz();
        }
    });

    topicBtn.addEventListener('click', startTopicQuiz);
}

// Quiz functionality
async function uploadFile(file) {
    showScreen('loading-screen');
    
    const formData = new FormData();
    formData.append('file', file);

    try {
        const response = await fetch(`${API_BASE_URL}/upload`, {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        
        if (data.error) {
            throw new Error(data.error);
        }

        // Initialize quiz state
        quizState.contentSource = 'file';
        quizState.topic = file.name;
        quizState.currentQuestion = data;
        
        displayQuestion(data);
        showScreen('quiz-screen');
        
    } catch (error) {
        console.error('Upload error:', error);
        showError(`Failed to upload file: ${error.message}`);
    }
}

async function startTopicQuiz() {
    const topic = document.getElementById('topic-input').value.trim();
    if (!topic) return;

    showScreen('loading-screen');
    
    try {
        const response = await fetch(`${API_BASE_URL}/generate`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                topic: topic,
                difficulty: quizState.difficulty,
                score: quizState.score,
                question_number: quizState.questionNumber
            })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        
        if (data.error) {
            throw new Error(data.error);
        }

        // Initialize quiz state
        quizState.contentSource = 'topic';
        quizState.topic = topic;
        quizState.currentQuestion = data;
        
        displayQuestion(data);
        showScreen('quiz-screen');
        
    } catch (error) {
        console.error('Topic quiz error:', error);
        showError(`Failed to generate question: ${error.message}`);
    }
}

function displayQuestion(questionData) {
    // Update question text
    document.getElementById('question-text').textContent = questionData.question;
    
    // Update options
    const optionsContainer = document.getElementById('options-container');
    optionsContainer.innerHTML = '';
    
    Object.entries(questionData.options).forEach(([key, value]) => {
        const optionElement = document.createElement('div');
        optionElement.className = 'option';
        optionElement.dataset.option = key;
        optionElement.innerHTML = `
            <span class="option-label">${key}</span>
            <span class="option-text">${value}</span>
        `;
        
        optionElement.addEventListener('click', () => selectOption(key));
        optionsContainer.appendChild(optionElement);
    });
    
    // Update progress display
    updateProgressDisplay();
    
    // Reset UI state
    quizState.selectedAnswer = null;
    document.getElementById('submit-answer').disabled = true;
    document.getElementById('results-section').classList.add('hidden');
}

function selectOption(option) {
    // Remove previous selection
    document.querySelectorAll('.option').forEach(opt => {
        opt.classList.remove('selected');
    });
    
    // Add selection to clicked option
    document.querySelector(`[data-option="${option}"]`).classList.add('selected');
    
    // Update state and enable submit button
    quizState.selectedAnswer = option;
    document.getElementById('submit-answer').disabled = false;
}

function initializeQuizControls() {
    document.getElementById('submit-answer').addEventListener('click', submitAnswer);
    document.getElementById('next-question').addEventListener('click', generateNextQuestion);
    document.getElementById('end-quiz').addEventListener('click', endQuiz);
}

function submitAnswer() {
    if (!quizState.selectedAnswer || !quizState.currentQuestion) return;
    
    const isCorrect = quizState.selectedAnswer === quizState.currentQuestion.correct_answer;
    
    // Update score and state
    quizState.updateScore(isCorrect);
    quizState.adjustDifficulty();
    
    // Display results
    displayResults(isCorrect);
    
    // Update progress
    updateProgressDisplay();
}

function displayResults(isCorrect) {
    const resultsSection = document.getElementById('results-section');
    const resultIcon = document.getElementById('result-icon');
    const resultTitle = document.getElementById('result-title');
    const explanationText = document.getElementById('explanation-text');
    const scoreChangeText = document.getElementById('score-change-text');
    
    // Update result header
    if (isCorrect) {
        resultIcon.innerHTML = '<i class="fas fa-check-circle"></i>';
        resultIcon.className = 'result-icon correct';
        resultTitle.textContent = 'Correct!';
        scoreChangeText.textContent = '+10 points';
        scoreChangeText.className = 'positive';
    } else {
        resultIcon.innerHTML = '<i class="fas fa-times-circle"></i>';
        resultIcon.className = 'result-icon incorrect';
        resultTitle.textContent = 'Incorrect';
        scoreChangeText.textContent = '-5 points';
        scoreChangeText.className = 'negative';
    }
    
    // Display explanations
    const explanations = quizState.currentQuestion.explanations;
    let explanationHTML = '';
    
    if (isCorrect) {
        explanationHTML = `
            <div class="explanation-item">
                <strong>Why this is correct:</strong><br>
                ${explanations.correct || explanations[quizState.currentQuestion.correct_answer]}
            </div>
        `;
    } else {
        explanationHTML = `
            <div class="explanation-item">
                <strong>The correct answer was ${quizState.currentQuestion.correct_answer}:</strong><br>
                ${explanations.correct || explanations[quizState.currentQuestion.correct_answer]}
            </div>
            <div class="explanation-item" style="margin-top: 1rem;">
                <strong>Why your answer (${quizState.selectedAnswer}) was incorrect:</strong><br>
                ${explanations[quizState.selectedAnswer]}
            </div>
        `;
    }
    
    explanationText.innerHTML = explanationHTML;
    
    // Show results section
    resultsSection.classList.remove('hidden');
    
    // Disable submit button
    document.getElementById('submit-answer').disabled = true;
}

async function generateNextQuestion() {
    quizState.questionNumber++;
    showScreen('loading-screen');
    
    try {
        let response;
        
        if (quizState.contentSource === 'topic') {
            // For topic-based questions, include previous wrong answer for targeted remediation
            const previousWrong = quizState.wrongStreak > 0 ? 
                `Previous question about: ${quizState.currentQuestion.question}` : null;
            
            response = await fetch(`${API_BASE_URL}/generate`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    topic: quizState.topic,
                    difficulty: quizState.difficulty,
                    score: quizState.score,
                    question_number: quizState.questionNumber,
                    previous_wrong: previousWrong
                })
            });
        } else {
            // For file-based questions, we'd need to implement file content persistence
            // For now, show an error asking user to restart
            throw new Error('File-based continuous questions not yet implemented. Please restart with a new file.');
        }

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        
        if (data.error) {
            throw new Error(data.error);
        }

        quizState.currentQuestion = data;
        displayQuestion(data);
        showScreen('quiz-screen');
        
    } catch (error) {
        console.error('Next question error:', error);
        showError(`Failed to generate next question: ${error.message}`);
    }
}

function endQuiz() {
    // Calculate final statistics
    const accuracy = quizState.totalQuestions > 0 ? 
        (quizState.correctAnswers / quizState.totalQuestions * 100).toFixed(1) : 0;
    
    const message = `
        Quiz completed!
        
        Final Statistics:
        • Questions answered: ${quizState.totalQuestions}
        • Correct answers: ${quizState.correctAnswers}
        • Accuracy: ${accuracy}%
        • Final score: ${quizState.score} points
        • Mastery level: ${quizState.masteryProgress.toFixed(1)}%
        
        Great job on your learning journey!
    `;
    
    alert(message);
    
    // Reset state and return to start
    Object.assign(quizState, new QuizState());
    showScreen('start-screen');
    
    // Reset form inputs
    document.getElementById('topic-input').value = '';
    document.getElementById('file-input').value = '';
    document.getElementById('char-count').textContent = '0';
    document.getElementById('upload-btn').disabled = true;
    document.getElementById('topic-btn').disabled = true;
    
    // Reset file upload UI
    document.querySelector('.upload-content').innerHTML = `
        <i class="fas fa-cloud-upload-alt"></i>
        <p>Click to upload or drag and drop</p>
        <span>PDF or TXT files only</span>
    `;
}

// Error handling
function initializeErrorHandling() {
    document.getElementById('retry-btn').addEventListener('click', () => {
        // Retry the last action based on content source
        if (quizState.contentSource === 'topic') {
            startTopicQuiz();
        } else {
            showScreen('start-screen');
        }
    });
    
    document.getElementById('back-to-start').addEventListener('click', () => {
        Object.assign(quizState, new QuizState());
        showScreen('start-screen');
    });
}

// Initialize application
document.addEventListener('DOMContentLoaded', () => {
    initializeFileUpload();
    initializeTopicInput();
    initializeQuizControls();
    initializeErrorHandling();
    
    // Show start screen
    showScreen('start-screen');
    
    console.log('Adaptive Learning Quiz System initialized');
});

