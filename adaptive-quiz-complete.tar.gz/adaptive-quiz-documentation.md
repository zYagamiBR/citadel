# Adaptive Learning Quiz System - User Documentation

## Application URLs

**Frontend Application:** https://fsibakuo.manus.space
**Backend API:** https://dyh6i3cqqee5.manus.space

## Overview

The Adaptive Learning Quiz System is a comprehensive web application designed specifically for ADHD and autistic learners who thrive on repetitive practice and detailed explanations. The system implements intelligent adaptive learning algorithms to provide personalized educational experiences.

## Key Features

### 🧠 Adaptive Learning Algorithm
- **3:1 Compensation Ratio**: For every incorrect answer, students must answer 3 questions correctly to compensate
- **Dynamic Difficulty Adjustment**: Questions automatically adjust between easy, medium, and hard based on performance
- **Mastery-Based Learning**: Quiz continues until true understanding is achieved (100% mastery)
- **Never Auto-Finalize**: Students control when to end sessions

### 📚 Input Methods
1. **File Upload**: Upload PDF or text files for content-based question generation
2. **Topic Input**: Enter any subject or topic for relevant question generation

### 🎯 Question Format
- Multiple choice with exactly 4 options (A, B, C, D)
- Single correct answer per question
- Varied difficulty levels based on performance

### 💡 Detailed Explanation System
- **Correct Answer Explanations**: Why the right answer is correct with examples and context
- **Wrong Answer Explanations**: Specific explanations for each incorrect option
- **Common Misconceptions**: Addresses typical learning pitfalls
- **Learning Tips**: Helps avoid similar mistakes in the future

### 📊 Scoring System
- Starting score: 100 points
- Correct answers: +10 points
- Incorrect answers: -5 points
- Real-time score tracking and progress display

### 🎨 Responsive Design
- **Mobile-Friendly**: Optimized for phones and tablets
- **Desktop Compatible**: Full-featured desktop experience
- **Accessibility Features**: High contrast mode, reduced motion support
- **Touch-Friendly**: Large buttons and intuitive interface

## How to Use

### Starting a Quiz

1. **Visit the Application**: Go to https://fsibakuo.manus.space
2. **Choose Input Method**:
   - **Upload Document**: Click the upload area and select a PDF or TXT file
   - **Enter Topic**: Type any subject in the text field (e.g., "JavaScript programming", "World War II", "Calculus")
3. **Start Quiz**: Click the appropriate "Start Quiz" button

### Taking the Quiz

1. **Read the Question**: Each question is clearly displayed with 4 multiple-choice options
2. **Select Answer**: Click on your chosen option (A, B, C, or D)
3. **Submit**: Click "Submit Answer" to see results
4. **Review Explanation**: Read detailed explanations for both correct and incorrect answers
5. **Continue**: Click "Next Question" to proceed or "End Quiz" to finish

### Understanding Progress

- **Question Number**: Shows current question in sequence
- **Score**: Real-time point tracking
- **Difficulty**: Current difficulty level (Easy/Medium/Hard)
- **Mastery Progress**: Visual progress bar showing learning advancement

## Technical Specifications

### Frontend
- **Framework**: Vanilla HTML, CSS, JavaScript
- **Responsive Design**: CSS Grid and Flexbox
- **Accessibility**: WCAG compliant with high contrast and reduced motion support
- **Browser Compatibility**: Modern browsers (Chrome, Firefox, Safari, Edge)

### Backend
- **Framework**: Flask (Python)
- **API Integration**: OpenAI GPT-3.5-turbo for question generation
- **File Processing**: PDF text extraction with PyPDF2
- **CORS Enabled**: Cross-origin requests supported

### Adaptive Learning Features
- **Difficulty Scaling**: 3-level system (easy → medium → hard)
- **Compensation Tracking**: 3:1 ratio enforcement
- **Concept Reinforcement**: Targeted question generation for weak areas
- **Performance Analytics**: Accuracy tracking and mastery calculation

## API Endpoints

### Health Check
- **URL**: `/api/health`
- **Method**: GET
- **Description**: Check API status

### File Upload
- **URL**: `/api/upload`
- **Method**: POST
- **Description**: Upload file and generate first question
- **Accepts**: PDF, TXT files

### Generate Question
- **URL**: `/api/generate`
- **Method**: POST
- **Description**: Generate question based on topic
- **Parameters**: topic, difficulty, previous_wrong

## Educational Benefits

### For ADHD Learners
- **Repetitive Practice**: Unlimited question generation for reinforcement
- **Immediate Feedback**: Instant explanations and scoring
- **Progress Tracking**: Visual indicators of advancement
- **Self-Paced Learning**: No time pressure or forced completion

### For Autistic Learners
- **Detailed Explanations**: Comprehensive reasoning for all answers
- **Systematic Approach**: Structured learning progression
- **Predictable Interface**: Consistent layout and navigation
- **Mastery Focus**: Emphasis on complete understanding

### For All Learners
- **Personalized Difficulty**: Adapts to individual skill level
- **Concept Reinforcement**: Targets areas needing improvement
- **Engaging Interface**: Modern, visually appealing design
- **Accessible Design**: Supports various learning needs

## Troubleshooting

### Common Issues

1. **Quiz Won't Start**
   - Check internet connection
   - Ensure file is PDF or TXT format
   - Try refreshing the page

2. **Questions Not Loading**
   - Verify backend API is accessible
   - Check browser console for errors
   - Try a different topic or file

3. **File Upload Issues**
   - Ensure file size is under 16MB
   - Check file format (PDF/TXT only)
   - Try a different file

### Browser Requirements
- JavaScript enabled
- Modern browser (Chrome 80+, Firefox 75+, Safari 13+, Edge 80+)
- Internet connection for API calls

## Support

For technical issues or questions about the Adaptive Learning Quiz System, the application includes built-in error handling and user-friendly error messages to guide users through any problems they may encounter.

## Privacy and Security

- No personal data is stored permanently
- Quiz sessions are temporary and client-side
- OpenAI API calls are made securely through the backend
- No tracking or analytics beyond basic usage

---

**Note**: This application is designed as an educational tool to support learning through adaptive practice and detailed explanations. It works best when used consistently over time to build mastery in chosen subjects.

